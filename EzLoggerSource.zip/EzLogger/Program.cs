﻿using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;
using System.Diagnostics;

namespace Logger
{
    class Program
    {
        static void Main(string[] args)
        {
            //user + folder locations
            string username = Environment.UserName;
            string EzLoggerFolder = @"C:\Users\" + username.ToString() + @"\AppData\Roaming\EzLogger";
            string LogFolder = @"C:\Users\" + username.ToString() + @"\AppData\Roaming\EzLogger\Logs";
            string SettingsFolder = @"C:\Users\" + username.ToString() + @"\AppData\Roaming\EzLogger\Settings";

            //Make the folders+settings file
            MakeFiles();
            void MakeFiles()
            {
                if (!Directory.Exists(EzLoggerFolder))
                {
                    Directory.CreateDirectory(EzLoggerFolder);
                }
                if (!Directory.Exists(LogFolder))
                {
                    Directory.CreateDirectory(LogFolder);
                }
                if (!Directory.Exists(SettingsFolder))
                {
                    Directory.CreateDirectory(SettingsFolder);
                }
                if(!File.Exists(SettingsFolder + @"\Settings.txt"))
                {
                    using (StreamWriter sw = File.CreateText(SettingsFolder + @"\Settings.txt")) ;
                }
            }

            //Change the color depending on settings
            ConsoleColor FgColor = ConsoleColor.White;
            PickColor(File.ReadAllText(SettingsFolder + @"\Settings.txt").ToString());
            void PickColor(string color)
            {
                switch (color.ToLower())
                {
                    case "pink": FgColor = ConsoleColor.Magenta; break;
                    case "red": FgColor = ConsoleColor.Red; break;
                    case "blue": FgColor = ConsoleColor.Blue; break;
                    case "white": FgColor = ConsoleColor.White; break;
                    case "cyan": FgColor = ConsoleColor.Cyan; break;
                    case "yellow": FgColor = ConsoleColor.Yellow; break;
                    case "green": FgColor = ConsoleColor.Green; break;
                    default:
                        break;
                }
            }

            //Show the main menu
            int MenuSelector = 1;
            ShowMenu();
            void ShowMenu()
            {
                MakeFgColor(FgColor);

                Write(@"
███████╗███████╗██╗      ██████╗  ██████╗  ██████╗ ███████╗██████╗ 
██╔════╝╚══███╔╝██║     ██╔═══██╗██╔════╝ ██╔════╝ ██╔════╝██╔══██╗
█████╗    ███╔╝ ██║     ██║   ██║██║  ███╗██║  ███╗█████╗  ██████╔╝
██╔══╝   ███╔╝  ██║     ██║   ██║██║   ██║██║   ██║██╔══╝  ██╔══██╗
███████╗███████╗███████╗╚██████╔╝╚██████╔╝╚██████╔╝███████╗██║  ██║
╚══════╝╚══════╝╚══════╝ ╚═════╝  ╚═════╝  ╚═════╝ ╚══════╝╚═╝  ╚═╝
                                                                   
        Welcome to EzLogger, What would you like to do?


");//Big Text up top

                WriteOptions();
                CheckInput();

                void WriteOptions()
                {
                    if (MenuSelector == 1) { MakeBgColor(FgColor); MakeFgColor(ConsoleColor.Black); }
                    Write("<<    Make a log   >>");
                    if (MenuSelector == 1) { MakeBgColor(ConsoleColor.Black); MakeFgColor(FgColor); }
                    if (MenuSelector == 2) { MakeBgColor(FgColor); MakeFgColor(ConsoleColor.Black); }
                    Write("<< Check old log's >>");
                    if (MenuSelector == 2) { MakeBgColor(ConsoleColor.Black); MakeFgColor(FgColor); }
                    if (MenuSelector == 3) { MakeBgColor(FgColor); MakeFgColor(ConsoleColor.Black); }
                    Write("<<     Settings    >>");
                    if (MenuSelector == 3) { MakeBgColor(ConsoleColor.Black); MakeFgColor(FgColor); }
                    if (MenuSelector == 4) { MakeBgColor(FgColor); MakeFgColor(ConsoleColor.Black); }
                    Write("");
                    Write("<<    Close app    >>");
                    if (MenuSelector == 4) { MakeBgColor(ConsoleColor.Black); MakeFgColor(FgColor); }
                }
                void CheckInput()
                {
                    ConsoleKeyInfo PressedKey = Console.ReadKey();
                    if (PressedKey.Key == ConsoleKey.DownArrow && MenuSelector < 4)
                    {
                        MenuSelector += 1;
                        Clear();
                        ShowMenu();
                    }
                    else if (PressedKey.Key == ConsoleKey.UpArrow && MenuSelector > 1)
                    {
                        MenuSelector -= 1;
                        Clear();
                        ShowMenu();
                    }
                    else if (PressedKey.Key == ConsoleKey.Enter)
                    {
                        GoToSelected();
                    }
                    else
                    {
                        Clear();
                        ShowMenu();
                    }
                }
                void GoToSelected()
                {
                    Clear();
                    switch (MenuSelector)
                    {
                        case 1:  MakeLog(); break;
                        case 2:  CheckLogs(); break;
                        case 3:  Settings(); break;
                        case 4:  Environment.Exit(0); break;
                        default: ShowMenu(); break;
                    }
                }
            }

            void MakeLog()
            {
                string fileName = @"\Log-" + DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss") + ".txt";
                string fullPath = LogFolder + fileName;
                using (StreamWriter sw = File.CreateText(fullPath)) ;

                List<string> Lines = new List<string>();

                Write("Type DONE when you are done");
                Write("");

                WriteLines();

                void WriteLines()
                {
                    string input = Console.ReadLine();
                    if(input.ToLower() == "done")
                    {
                        FinishLog();
                    }
                    else
                    {
                        Lines.Add(input);
                        WriteLines();
                    }
                }

                void FinishLog()
                {
                    File.WriteAllLines(fullPath, Lines);
                }
                Clear();
                ShowMenu();
            }

            void CheckLogs()
            {
                MenuSelector = 1;


                List<string> Files = new List<string>();
                Files.AddRange(Directory.GetFiles(LogFolder, "*", SearchOption.AllDirectories).Select(f => Path.GetFileName(f)));
                Files.Reverse();

                LogsMenu();
                void LogsMenu()
                {
                    WriteAllLogs();
                    CheckInput();
                }
                void WriteAllLogs()
                {
                    Write("Press ENTER to check a log");
                    Write("Press DELETE to delete a log");
                    Write("");

                    for (int i = 0; i < Files.Count(); i++)
                    {
                        if (MenuSelector == i+1) { MakeBgColor(FgColor); MakeFgColor(ConsoleColor.Black); }
                        Write(Files[i]);
                        if (MenuSelector == i + 1) { MakeBgColor(ConsoleColor.Black); MakeFgColor(FgColor); }
                    }
                }
                void CheckInput()
                {
                    ConsoleKeyInfo PressedKey = Console.ReadKey();
                    if (PressedKey.Key == ConsoleKey.DownArrow && MenuSelector < Files.Count)
                    {
                        MenuSelector += 1;
                        Clear();
                        LogsMenu();
                    }
                    else if (PressedKey.Key == ConsoleKey.UpArrow && MenuSelector > 1)
                    {
                        MenuSelector -= 1;
                        Clear();
                        LogsMenu();
                    }
                    else if (PressedKey.Key == ConsoleKey.Enter)
                    {
                        GoToSelected();
                    }
                    else if (PressedKey.Key == ConsoleKey.Delete)
                    {
                        GoToDelete();
                    }
                    else
                    {
                        Clear();
                        LogsMenu();
                    }
                }
                void GoToSelected()
                {
                    Clear();
                    string filetowrite = (LogFolder + @"\" + Files[MenuSelector - 1]);
                    Write(Files[MenuSelector - 1]);
                    Write("");
                    Write(System.IO.File.ReadAllText(filetowrite));
                    Write("");
                    MakeBgColor(FgColor); MakeFgColor(ConsoleColor.Black);
                    Write("<<   Go back to menu   >>");
                    MakeBgColor(ConsoleColor.Black); MakeFgColor(FgColor);

                    if(Console.ReadKey(true).Key == ConsoleKey.Enter)
                    {
                        Clear();
                        MenuSelector = 1;
                        ShowMenu();
                    }
                }
                void GoToDelete()
                {
                    string FileToDelete = Files[MenuSelector - 1];
                    int FilePrefix = (MenuSelector - 1);
                    string FileToDeleteDir = (LogFolder + @"\" + Files[MenuSelector - 1]);
                    MenuSelector = 1;
                    Clear();

                    DeleteMenu();

                    void DeleteMenu()
                    {
                        writeText();
                        CheckInput();
                    }

                    void writeText()
                    {
                        Write("Are you SURE you want to delete this log?");
                        Write("");
                        Write(FileToDelete);
                        Write("");
                        if (MenuSelector == 1) { MakeBgColor(FgColor); MakeFgColor(ConsoleColor.Black); }
                        Write("<<   YES!   >>");
                        if (MenuSelector == 1) { MakeBgColor(ConsoleColor.Black); MakeFgColor(FgColor); }

                        if (MenuSelector == 2) { MakeBgColor(FgColor); MakeFgColor(ConsoleColor.Black); }
                        Write("<<   NO!   >>");
                        if (MenuSelector == 2) { MakeBgColor(ConsoleColor.Black); MakeFgColor(FgColor); }
                    }
                    void CheckInput()
                    {
                        ConsoleKeyInfo PressedKey = Console.ReadKey();
                        if (PressedKey.Key == ConsoleKey.DownArrow && MenuSelector < 2)
                        {
                            MenuSelector += 1;
                            Clear();
                            DeleteMenu();
                        }
                        else if (PressedKey.Key == ConsoleKey.UpArrow && MenuSelector > 1)
                        {
                            MenuSelector -= 1;
                            Clear();
                            DeleteMenu();
                        }
                        else if (PressedKey.Key == ConsoleKey.Enter)
                        {
                            SelectDel();
                        }
                        else
                        {
                            Clear();
                            LogsMenu();
                        }
                    }
                    void SelectDel()
                    {
                        if(MenuSelector == 1)
                        {
                            Files.RemoveAt(FilePrefix);

                            File.Delete(FileToDeleteDir);

                            Write("");
                            Write("Succesfully deleted");

                            MakeBgColor(FgColor); MakeFgColor(ConsoleColor.Black);
                            Write("");
                            Write("<<   Go back to menu   >>");
                            MakeBgColor(ConsoleColor.Black); MakeFgColor(FgColor);

                            if (Console.ReadKey(true).Key == ConsoleKey.Enter)
                            {
                                Clear();
                                ShowMenu();
                            }
                        }
                        else
                        {
                            Clear();
                            ShowMenu();
                        }
                    }

                    if (Console.ReadKey(true).Key == ConsoleKey.Enter)
                    {
                        Clear();
                        ShowMenu();
                    }
                }
            }

            void Settings()
            {
                OpenSettingsMenu();

                void OpenSettingsMenu()
                {
                    MakeFgColor(FgColor);

                    Write(@"
███████╗███████╗██╗      ██████╗  ██████╗  ██████╗ ███████╗██████╗ 
██╔════╝╚══███╔╝██║     ██╔═══██╗██╔════╝ ██╔════╝ ██╔════╝██╔══██╗
█████╗    ███╔╝ ██║     ██║   ██║██║  ███╗██║  ███╗█████╗  ██████╔╝
██╔══╝   ███╔╝  ██║     ██║   ██║██║   ██║██║   ██║██╔══╝  ██╔══██╗
███████╗███████╗███████╗╚██████╔╝╚██████╔╝╚██████╔╝███████╗██║  ██║
╚══════╝╚══════╝╚══════╝ ╚═════╝  ╚═════╝  ╚═════╝ ╚══════╝╚═╝  ╚═╝
                                                                   
        Welcome to EzLogger, What would you like to do?


");//Big Text up top

                    WriteOptions();
                    CheckInput();

                    void WriteOptions()
                    {
                        if (MenuSelector == 1) { MakeBgColor(FgColor); MakeFgColor(ConsoleColor.Black); }
                        Write("<<      Change color    >>");
                        if (MenuSelector == 1) { MakeBgColor(ConsoleColor.Black); MakeFgColor(FgColor); }
                        if (MenuSelector == 2) { MakeBgColor(FgColor); MakeFgColor(ConsoleColor.Black); }
                        Write("<< Open Folder location >>");
                        if (MenuSelector == 2) { MakeBgColor(ConsoleColor.Black); MakeFgColor(FgColor); }
                        if (MenuSelector == 3) { MakeBgColor(FgColor); MakeFgColor(ConsoleColor.Black); }
                        Write("");
                        Write("<<     Back to start    >>");
                        if (MenuSelector == 3) { MakeBgColor(ConsoleColor.Black); MakeFgColor(FgColor); }
                    }
                    void CheckInput()
                    {
                        ConsoleKeyInfo PressedKey = Console.ReadKey();
                        if (PressedKey.Key == ConsoleKey.DownArrow && MenuSelector < 3)
                        {
                            MenuSelector += 1;
                            Clear();
                            OpenSettingsMenu();
                        }
                        else if (PressedKey.Key == ConsoleKey.UpArrow && MenuSelector > 1)
                        {
                            MenuSelector -= 1;
                            Clear();
                            OpenSettingsMenu();
                        }
                        else if (PressedKey.Key == ConsoleKey.Enter)
                        {
                            GoToSelected();
                        }
                        else
                        {
                            Clear();
                            OpenSettingsMenu();
                        }
                    }
                    void GoToSelected()
                    {
                        Clear();
                        switch (MenuSelector)
                        {
                            case 1: ChangeColor(); break;
                            case 2: Process.Start("explorer.exe", @"C:\Users\" + username.ToString() + @"\AppData\Roaming\EzLogger");
                                ShowMenu(); break;
                            case 3: ShowMenu();  break;
                            default: ShowMenu(); break;
                        }
                    }
                }

                void ChangeColor()
                {
                    OpenColorMenu();

                    void OpenColorMenu()
                    {
                        MakeFgColor(FgColor);

                        WriteOptions();
                        CheckInput();

                        void WriteOptions()
                        {
                            if (MenuSelector == 1) { MakeBgColor(FgColor); MakeFgColor(ConsoleColor.Black); }
                            Write("<<   pink   >>");
                            if (MenuSelector == 1) { MakeBgColor(ConsoleColor.Black); MakeFgColor(FgColor); }
                            if (MenuSelector == 2) { MakeBgColor(FgColor); MakeFgColor(ConsoleColor.Black); }
                            Write("<<   red    >>");
                            if (MenuSelector == 2) { MakeBgColor(ConsoleColor.Black); MakeFgColor(FgColor); }
                            if (MenuSelector == 3) { MakeBgColor(FgColor); MakeFgColor(ConsoleColor.Black); }
                            Write("<<   blue   >>");
                            if (MenuSelector == 3) { MakeBgColor(ConsoleColor.Black); MakeFgColor(FgColor); }
                            if (MenuSelector == 4) { MakeBgColor(FgColor); MakeFgColor(ConsoleColor.Black); }
                            Write("<<  White   >>");
                            if (MenuSelector == 4) { MakeBgColor(ConsoleColor.Black); MakeFgColor(FgColor); }
                            if (MenuSelector == 5) { MakeBgColor(FgColor); MakeFgColor(ConsoleColor.Black); }
                            Write("<<   Cyan   >>");
                            if (MenuSelector == 5) { MakeBgColor(ConsoleColor.Black); MakeFgColor(FgColor); }
                            if (MenuSelector == 6) { MakeBgColor(FgColor); MakeFgColor(ConsoleColor.Black); }
                            Write("<<  Yellow  >>");
                            if (MenuSelector == 6) { MakeBgColor(ConsoleColor.Black); MakeFgColor(FgColor); }
                            if (MenuSelector == 7) { MakeBgColor(FgColor); MakeFgColor(ConsoleColor.Black); }
                            Write("<<  Green   >>");
                            if (MenuSelector == 7) { MakeBgColor(ConsoleColor.Black); MakeFgColor(FgColor); }
                        }
                        void CheckInput()
                        {
                            ConsoleKeyInfo PressedKey = Console.ReadKey();
                            if (PressedKey.Key == ConsoleKey.DownArrow && MenuSelector < 7)
                            {
                                MenuSelector += 1;
                                Clear();
                                OpenColorMenu();
                            }
                            else if (PressedKey.Key == ConsoleKey.UpArrow && MenuSelector > 1)
                            {
                                MenuSelector -= 1;
                                Clear();
                                OpenColorMenu();
                            }
                            else if (PressedKey.Key == ConsoleKey.Enter)
                            {
                                GoToSelected();
                            }
                            else
                            {
                                Clear();
                                OpenColorMenu();
                            }
                        }
                        void GoToSelected()
                        {
                            Clear();
                            switch (MenuSelector)
                            {
                                case 1: FgColor = ConsoleColor.Magenta; break;
                                case 2: FgColor = ConsoleColor.Red; break;
                                case 3: FgColor = ConsoleColor.Blue; break;
                                case 4: FgColor = ConsoleColor.White; break;
                                case 5: FgColor = ConsoleColor.Cyan; break;
                                case 6: FgColor = ConsoleColor.Yellow; break;
                                case 7: FgColor = ConsoleColor.Green; break;
                                default: ShowMenu(); break;
                            }

                            File.WriteAllText(SettingsFolder + @"\Settings.txt", String.Empty);
                            File.WriteAllText(SettingsFolder + @"\Settings.txt", FgColor.ToString());

                            MenuSelector = 1;
                            ShowMenu();
                        }
                    }
                }
            }

            void MakeBgColor(ConsoleColor color)
            {
                Console.BackgroundColor = color;
            }
            void MakeFgColor(ConsoleColor color)
            {
                Console.ForegroundColor = color;
            }
            void Clear()
            {
                Console.Clear();
            }
            void Write(string text)
            {
                Console.WriteLine(text);
            }
            bool CheckKey(ConsoleKey keytocheck)
            {
                if(Console.ReadKey(true).Key == (keytocheck))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
    }
}
